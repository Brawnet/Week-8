﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH_WEEK_6
{
    public partial class Form1 : Form
    {
        DataTable Keranjang;
        double[] TotalHarga = new double[20];
        double HargaTotal;
        double HargaTotal1;
        double HargaTotal2;
        double HargaTotal3;
        double HargaTotal4;
        double HargaTotal5;
        double HargaTotal6;
        double HargaTotal7;
        double HargaTotal8;
        double HargaTotal9;
        double HargaTotal10;
        double HargaTotal11;
        double HargaTotal12; 
        double HargaTotal13;
        double HargaTotal14;
        double HargaTotal15;
        double HargaTotal16;
        double HargaTotal17;
        double HargaTotal18;
        double HargaTotal19;
        int Hitung1 = 0;
        int Hitung2 = 0;
        int Hitung3 = 0;
        int Hitung4 = 0;
        int Hitung5 = 0;
        int Hitung6 = 0;
        int Hitung7 = 0; 
        int Hitung8 = 0;
        int Hitung9 = 0;
        int Hitung10 = 0;
        int Hitung11 = 0;
        int Hitung12 = 0;
        int Hitung13 = 0;
        int Hitung14 = 0;
        int Hitung15 = 0;
        int Hitung16 = 0;
        int Hitung17 = 0;
        int Hitung18 = 0;
        public Form1()
        {
            InitializeComponent();
            TB_Harga.KeyPress += new KeyPressEventHandler(TB_Harga_KeyPress);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            

            PN_Shirt.Anchor = AnchorStyles.Top;
            PN_TShirt.Anchor = AnchorStyles.Bottom;
            PN_Shoes.Anchor = AnchorStyles.Right;

            Keranjang = new DataTable();
            Keranjang.Columns.Add("Item Name");
            Keranjang.Columns.Add("Quantity");
            Keranjang.Columns.Add("Price");
            Keranjang.Columns.Add("Total");

            DGV_Keranjang.DataSource = Keranjang;


        }
        private void TB_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
      
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; 
            }
        }

        public string Titik(double number)
        {
            System.Globalization.CultureInfo culture = new System.Globalization.CultureInfo("id-ID");
            string formattedNumber = number.ToString("N0", culture);
            return formattedNumber;
        }

        private void TShirt_Click(object sender, EventArgs e)
        {
            Ganti();
            PN_TShirt.Visible = true;
        }

        private void Shirt_Click(object sender, EventArgs e)
        {
            Ganti();
            PN_Shirt.Visible = true;
        }

        private void Pants_Click(object sender, EventArgs e)
        {
            Ganti();
            PN_Pants.Visible = true;
        }

        private void LongPants_Click(object sender, EventArgs e)
        {
            Ganti();
            PN_LongPants.Visible = true;
        }
        private void Shoes_Click(object sender, EventArgs e)
        {
            Ganti();
            Panel_Shoes.Visible = true;
        }

        private void Jawelleries_Click(object sender, EventArgs e)
        {
            Ganti();
            PN_Jawelleries.Visible = true;
        }

        private void Others_Click(object sender, EventArgs e)
        {
            TB_Nama.Text = string.Empty;
            TB_Harga.Text = string.Empty;
            PB_New.Image = null;
            Ganti();
            PN_Others.Visible = true;
            TB_Nama.Enabled = false;
            TB_Harga.Enabled = false;
            BT_Other.Enabled = false;
        }
        private void Ganti()
        {
            if (PN_TShirt.Visible == true)
            {
                PN_TShirt.Visible = false;
            }
            if (PN_Shirt.Visible == true)
            {
                PN_Shirt.Visible = false;
            }
            if (PN_Pants.Visible == true)
            {
                PN_Pants.Visible = false;
            }
            if (PN_LongPants.Visible == true)
            {
                PN_LongPants.Visible = false;
            }
            if (Panel_Shoes.Visible == true)
            {
                Panel_Shoes.Visible = false;
            }
            if (PN_Jawelleries.Visible == true)
            {
                PN_Jawelleries.Visible = false;
            }
            if (PN_Others.Visible == true)
            {
                PN_Others.Visible = false;
            }
        }

        private void BT_TShirt1_Click(object sender, EventArgs e)
        {
            if (Hitung1 == 0)
            {
                Hitung1 = 1;
                Keranjang.Rows.Add("Uniklo Biru", Hitung1, "200.000", "200.000");

            }
            else if (Hitung1 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Uniklo Biru")
                    {
                        Hitung1++;
                        row.Cells["Quantity"].Value = Hitung1;
                        row.Cells["Total"].Value = Titik(Hitung1 * 200000);

                    }
                }
            }
            HargaTotal1 = Hitung1 * 200000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;
            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";
        }

        private void BT_TShirt2_Click(object sender, EventArgs e)
        {
            if (Hitung2 == 0)
            {
                Hitung2 = 1;
                Keranjang.Rows.Add("Uniklo Coklat Saku", Hitung2, "250.000", "250.000");

            }
            else if (Hitung2 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Uniklo Coklat Saku")
                    {
                        Hitung2++;
                        row.Cells["Quantity"].Value = Hitung2;
                        row.Cells["Total"].Value = Titik(Hitung2 * 250000);
                    }
                }
            }
            HargaTotal2 = Hitung2 * 250000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;
            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_TShirt3_Click(object sender, EventArgs e)
        {
            if (Hitung3 == 0)
            {
                Hitung3 = 1;
                Keranjang.Rows.Add("Uniklo Khaki", Hitung3, "200.000", "200.000");
            }
            else if (Hitung3 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Uniklo Khaki")
                    {
                        Hitung3++;
                        row.Cells["Quantity"].Value = Hitung3;
                        row.Cells["Total"].Value = Titik(Hitung3 * 200000);
                    }
                }
            }
            HargaTotal3 = Hitung3 * 200000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;
            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shirt1_Click(object sender, EventArgs e)
        {
            if (Hitung4 == 0)
            {
                Hitung4 = 1;
                Keranjang.Rows.Add("Kemeja Hijau", Hitung4, "250.000", "250.000");

            }
            else if (Hitung4 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Kemeja Hijau")
                    {
                        Hitung4++;
                        row.Cells["Quantity"].Value = Hitung4;
                        row.Cells["Total"].Value = Titik(Hitung4 * 250000);
                    }
                }
            }
            HargaTotal4 = Hitung4 * 250000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;
            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik( HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shirt2_Click(object sender, EventArgs e)
        {
            if (Hitung5 == 0)
            {
                Hitung5 = 1;
                Keranjang.Rows.Add("Kemeja Putih", Hitung5, "300.000", "300.000");

            }
            else if (Hitung5 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Kemeja Putih")
                    {
                        Hitung5++;
                        row.Cells["Quantity"].Value = Hitung5;
                        row.Cells["Total"].Value = Titik(Hitung5 * 300000);
                    }
                }
            }
            HargaTotal5 = Hitung5 * 300000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik( HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shirt3_Click(object sender, EventArgs e)
        {
            if (Hitung6 == 0)
            {
                Hitung6 = 1;
                Keranjang.Rows.Add("Kemeja Kotak Kotak", Hitung6, "400.000", "400.000");

            }
            else if (Hitung6 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Kemeja Kotak Kotak")
                    {
                        Hitung6++;
                        row.Cells["Quantity"].Value = Hitung6;
                        row.Cells["Total"].Value = Titik(Hitung6 * 400000);
                    }
                }
            }
            HargaTotal6 = Hitung6 * 400000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik( HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Pants1_Click(object sender, EventArgs e)
        {
            if (Hitung7 == 0)
            {
                Hitung7 = 1;
                Keranjang.Rows.Add("Celana Pendek Hijau", Hitung7, "100.000", "100.000");
            }
            else if (Hitung7 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Pendek Hijau")
                    {
                        Hitung7++;
                        row.Cells["Quantity"].Value = Hitung7;
                        row.Cells["Total"].Value = Titik(Hitung7 * 100000);
                    }
                }
            }
            HargaTotal7 = Hitung7 * 100000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Pants2_Click(object sender, EventArgs e)
        {
            if (Hitung8 == 0)
            {
                Hitung8 = 1;
                Keranjang.Rows.Add("Celana Pendek Hitam", Hitung8, "50.000", "50.000");

            }
            else if (Hitung8 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Pendek Hitam")
                    {
                        Hitung8++;
                        row.Cells["Quantity"].Value = Hitung8;
                        row.Cells["Total"].Value = Titik(Hitung8 * 50000);
                    }
                }
            }
            HargaTotal8 = Hitung8 * 50000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Pants3_Click(object sender, EventArgs e)
        {
            if (Hitung9 == 0)
            {
                Hitung9 = 1;
                Keranjang.Rows.Add("Celana Pendek Abu Abu", Hitung9, "75.000", "75.000");

            }
            else if (Hitung9 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Pendek Abu Abu")
                    {
                        Hitung9++;
                        row.Cells["Quantity"].Value = Hitung9;
                        row.Cells["Total"].Value = Titik(Hitung9 * 75000);
                    }
                }
            }
            HargaTotal9 = Hitung9 * 75000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";
        }

        private void BT_LongPants1_Click(object sender, EventArgs e)
        {
            if (Hitung10 == 0)
            {
                Hitung10 = 1;
                Keranjang.Rows.Add("Celana Hijau", Hitung10, "300.000", "300.000");

            }
            else if (Hitung10 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Hijau")
                    {
                        Hitung10++;
                        row.Cells["Quantity"].Value = Hitung10;
                        row.Cells["Total"].Value = Titik(Hitung10 * 300000);
                    }
                }
            }
            HargaTotal10 = Hitung10 * 300000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_LongPants2_Click(object sender, EventArgs e)
        {
            if (Hitung11 == 0)
            {
                Hitung11 = 1;
                Keranjang.Rows.Add("Celana Coklat", Hitung11, "250.000", "250.000");
                
            }
            else if (Hitung11 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Coklat")
                    {
                        Hitung11++;
                        row.Cells["Quantity"].Value = Hitung11;
                        row.Cells["Total"].Value = Titik(Hitung11 * 250000);
                    }
                }
            }
            HargaTotal11 = Hitung11 * 250000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";
        }

        private void BT_LongPants3_Click(object sender, EventArgs e)
        {
            if (Hitung12 == 0)
            {
                Hitung12 = 1;
                Keranjang.Rows.Add("Celana Biru", Hitung12, "175.000", "175.000");
                
            }
            else if (Hitung12 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Celana Biru")
                    {
                        Hitung12++;
                        row.Cells["Quantity"].Value = Hitung12;
                        row.Cells["Total"].Value = Titik(Hitung12 * 175000);
                    }
                }
            }
            HargaTotal12 = Hitung12 * 175000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shoes1_Click(object sender, EventArgs e)
        {
            if (Hitung13 == 0)
            {
                Hitung13 = 1;
                Keranjang.Rows.Add("Sepatu Nike", Hitung13, "1.100.000", "1.100.000");
                
            }
            else if (Hitung13 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Sepatu Nike")
                    {
                        Hitung13++;
                        row.Cells["Quantity"].Value = Hitung13;
                        row.Cells["Total"].Value = Titik(Hitung13 * 1100000);
                    }
                }
            }
            HargaTotal13 = Hitung13 * 1100000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shoes2_Click(object sender, EventArgs e)
        {
            if (Hitung14 == 0)
            {
                Hitung14 = 1;
                Keranjang.Rows.Add("Sepatu ReBook", Hitung14, "1.250.000", "1.250.000");

            }
            else if (Hitung14 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Sepatu Rebook")
                    {
                        Hitung14++;
                        row.Cells["Quantity"].Value = Hitung14;
                        row.Cells["Total"].Value = Titik(Hitung14 * 1250000);
                    }
                }
            }
            HargaTotal14 = Hitung14 * 1250000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Shoes3_Click(object sender, EventArgs e)
        {
            if (Hitung15 == 0)
            {
                Hitung15 = 1;
                Keranjang.Rows.Add("Sepatu Adidas", Hitung15, "1.200.000", "1.200.000");

            }
            else if (Hitung15 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Sepatu Adidas")
                    {
                        Hitung15++;
                        row.Cells["Quantity"].Value = Hitung15;
                        row.Cells["Total"].Value = Titik(Hitung15 * 1200000);
                    }
                }
            }
            HargaTotal15 = Hitung15 * 1200000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Jawelleries1_Click(object sender, EventArgs e)
        {
            if (Hitung16 == 0)
            {
                Hitung16 = 1;
                Keranjang.Rows.Add("Diamond", Hitung16, "5.000.000", "5.000.000");

            }
            else if (Hitung16 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Diamond")
                    {
                        Hitung16++;
                        row.Cells["Quantity"].Value = Hitung16;
                        row.Cells["Total"].Value = Titik(Hitung16 * 5000000);
                    }
                }
            }
            HargaTotal16 = Hitung16 * 5000000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Jawelleries2_Click(object sender, EventArgs e)
        {
            if (Hitung17 == 0)
            {
                Hitung17 = 1;
                Keranjang.Rows.Add("Gold", Hitung17, "1.000.000", "1.000.000");

            }
            else if (Hitung17 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Gold")
                    {
                        Hitung17++;
                        row.Cells["Quantity"].Value = Hitung17;
                        row.Cells["Total"].Value = Titik(Hitung17 * 1000000);
                    }
                }
            }
            HargaTotal17 = Hitung17 * 1000000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Jawelleries3_Click(object sender, EventArgs e)
        {
            if (Hitung18 == 0)
            {
                Hitung18 = 1;
                Keranjang.Rows.Add("Platinum", Hitung18, "500.000", "500.000");

            }
            else if (Hitung18 >= 1)
            {
                foreach (DataGridViewRow row in DGV_Keranjang.Rows)
                {
                    if (row.Cells["Item Name"].Value.ToString() == "Platinum")
                    {
                        Hitung18++;
                        row.Cells["Quantity"].Value = Hitung18;
                        row.Cells["Total"].Value = Titik(Hitung18 * 500000);
                    }
                }
            }
            HargaTotal18 = Hitung18 * 500000;
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";

        }

        private void BT_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp; *.png";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                PB_New.Image = new Bitmap(openFileDialog.FileName);
                // Setelah gambar diunggah, aktifkan TextBox
                TB_Nama.Enabled = true;
                TB_Harga.Enabled = true;
            }
        }

        private void TB_Nama_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TB_Nama.Text) && !string.IsNullOrEmpty(TB_Harga.Text))
            {
                BT_Other.Enabled = true;
            }
            else
            {
                BT_Other.Enabled = false;
            }
        }

        private void TB_Harga_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TB_Nama.Text) && !string.IsNullOrEmpty(TB_Harga.Text))
            {
                BT_Other.Enabled = true;
            }
            else
            {
                BT_Other.Enabled = false;
            }
        }

        private void PN_Others_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Panel_Shoes_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BT_Other_Click(object sender, EventArgs e)
        {
            Keranjang.Rows.Add(TB_Nama.Text, "1", Titik(Convert.ToDouble(TB_Harga.Text)), Titik(Convert.ToDouble(TB_Harga.Text)));
            HargaTotal19 = HargaTotal19 + Convert.ToDouble(TB_Harga.Text);
            HargaTotal = HargaTotal1 + HargaTotal2 + HargaTotal3 + HargaTotal4 + HargaTotal5 + HargaTotal6 + HargaTotal7 + HargaTotal8 + HargaTotal9 + HargaTotal10 + HargaTotal11 + HargaTotal12 + HargaTotal13 + HargaTotal14 + HargaTotal15 + HargaTotal16 + HargaTotal17 + HargaTotal18 + HargaTotal19;

            TB_Total.Text = $"Rp. {Convert.ToString(Titik(HargaTotal))}";
            TB_SubTotal.Text = $"Rp. {Convert.ToString(Titik(HargaTotal + HargaTotal * 0.1))}";
        }

      
    }
}
