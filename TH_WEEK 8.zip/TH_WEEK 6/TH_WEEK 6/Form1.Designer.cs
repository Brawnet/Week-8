﻿namespace TH_WEEK_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TShirt = new System.Windows.Forms.ToolStripMenuItem();
            this.Shirt = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Pants = new System.Windows.Forms.ToolStripMenuItem();
            this.LongPants = new System.Windows.Forms.ToolStripMenuItem();
            this.accesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Shoes = new System.Windows.Forms.ToolStripMenuItem();
            this.Jawelleries = new System.Windows.Forms.ToolStripMenuItem();
            this.Others = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.DGV_Keranjang = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_Total = new System.Windows.Forms.TextBox();
            this.TB_SubTotal = new System.Windows.Forms.TextBox();
            this.PN_Jawelleries = new System.Windows.Forms.Panel();
            this.BT_Jawelleries3 = new System.Windows.Forms.Button();
            this.BT_Jawelleries2 = new System.Windows.Forms.Button();
            this.BT_Jawelleries1 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.PN_Others = new System.Windows.Forms.Panel();
            this.BT_Other = new System.Windows.Forms.Button();
            this.TB_Nama = new System.Windows.Forms.TextBox();
            this.TB_Harga = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.BT_Upload = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.PB_New = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.BT_TShirt1 = new System.Windows.Forms.Button();
            this.BT_TShirt2 = new System.Windows.Forms.Button();
            this.BT_TShirt3 = new System.Windows.Forms.Button();
            this.Panel_Shoes = new System.Windows.Forms.Panel();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.BT_Shoes3 = new System.Windows.Forms.Button();
            this.BT_Shoes2 = new System.Windows.Forms.Button();
            this.BT_Shoes1 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.PN_Shoes = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.PN_TShirt = new System.Windows.Forms.Panel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.BT_LongPants1 = new System.Windows.Forms.Button();
            this.BT_LongPants2 = new System.Windows.Forms.Button();
            this.BT_LongPants3 = new System.Windows.Forms.Button();
            this.PN_LongPants = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.BT_Pants1 = new System.Windows.Forms.Button();
            this.BT_Pants2 = new System.Windows.Forms.Button();
            this.BT_Pants3 = new System.Windows.Forms.Button();
            this.PN_Pants = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.BT_Shirt1 = new System.Windows.Forms.Button();
            this.BT_Shirt2 = new System.Windows.Forms.Button();
            this.BT_Shirt3 = new System.Windows.Forms.Button();
            this.PN_Shirt = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Keranjang)).BeginInit();
            this.PN_Jawelleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.PN_Others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_New)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Panel_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PN_Shoes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.PN_TShirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.PN_LongPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.PN_Pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.PN_Shirt.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.buttonWearToolStripMenuItem,
            this.accesToolStripMenuItem,
            this.Others});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1072, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TShirt,
            this.Shirt});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 26);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // TShirt
            // 
            this.TShirt.Name = "TShirt";
            this.TShirt.Size = new System.Drawing.Size(136, 26);
            this.TShirt.Text = "T-Shirt";
            this.TShirt.Click += new System.EventHandler(this.TShirt_Click);
            // 
            // Shirt
            // 
            this.Shirt.Name = "Shirt";
            this.Shirt.Size = new System.Drawing.Size(136, 26);
            this.Shirt.Text = "Shirt";
            this.Shirt.Click += new System.EventHandler(this.Shirt_Click);
            // 
            // buttonWearToolStripMenuItem
            // 
            this.buttonWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Pants,
            this.LongPants});
            this.buttonWearToolStripMenuItem.Name = "buttonWearToolStripMenuItem";
            this.buttonWearToolStripMenuItem.Size = new System.Drawing.Size(110, 26);
            this.buttonWearToolStripMenuItem.Text = "Buttom Wear";
            // 
            // Pants
            // 
            this.Pants.Name = "Pants";
            this.Pants.Size = new System.Drawing.Size(163, 26);
            this.Pants.Text = "Pants";
            this.Pants.Click += new System.EventHandler(this.Pants_Click);
            // 
            // LongPants
            // 
            this.LongPants.Name = "LongPants";
            this.LongPants.Size = new System.Drawing.Size(163, 26);
            this.LongPants.Text = "Long Pants";
            this.LongPants.Click += new System.EventHandler(this.LongPants_Click);
            // 
            // accesToolStripMenuItem
            // 
            this.accesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Shoes,
            this.Jawelleries});
            this.accesToolStripMenuItem.Name = "accesToolStripMenuItem";
            this.accesToolStripMenuItem.Size = new System.Drawing.Size(99, 26);
            this.accesToolStripMenuItem.Text = "Accessories";
            // 
            // Shoes
            // 
            this.Shoes.Name = "Shoes";
            this.Shoes.Size = new System.Drawing.Size(163, 26);
            this.Shoes.Text = "Shoes";
            this.Shoes.Click += new System.EventHandler(this.Shoes_Click);
            // 
            // Jawelleries
            // 
            this.Jawelleries.Name = "Jawelleries";
            this.Jawelleries.Size = new System.Drawing.Size(163, 26);
            this.Jawelleries.Text = "Jawelleries";
            this.Jawelleries.Click += new System.EventHandler(this.Jawelleries_Click);
            // 
            // Others
            // 
            this.Others.Name = "Others";
            this.Others.Size = new System.Drawing.Size(66, 26);
            this.Others.Text = "Others";
            this.Others.Click += new System.EventHandler(this.Others_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // DGV_Keranjang
            // 
            this.DGV_Keranjang.AllowUserToAddRows = false;
            this.DGV_Keranjang.AllowUserToResizeColumns = false;
            this.DGV_Keranjang.AllowUserToResizeRows = false;
            this.DGV_Keranjang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Keranjang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Keranjang.EnableHeadersVisualStyles = false;
            this.DGV_Keranjang.Location = new System.Drawing.Point(630, 44);
            this.DGV_Keranjang.Name = "DGV_Keranjang";
            this.DGV_Keranjang.RowHeadersVisible = false;
            this.DGV_Keranjang.RowHeadersWidth = 51;
            this.DGV_Keranjang.RowTemplate.Height = 24;
            this.DGV_Keranjang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Keranjang.Size = new System.Drawing.Size(430, 238);
            this.DGV_Keranjang.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(630, 302);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Total        :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(632, 341);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sub Total :";
            // 
            // TB_Total
            // 
            this.TB_Total.Location = new System.Drawing.Point(754, 306);
            this.TB_Total.Name = "TB_Total";
            this.TB_Total.ReadOnly = true;
            this.TB_Total.Size = new System.Drawing.Size(187, 22);
            this.TB_Total.TabIndex = 6;
            // 
            // TB_SubTotal
            // 
            this.TB_SubTotal.Location = new System.Drawing.Point(754, 345);
            this.TB_SubTotal.Name = "TB_SubTotal";
            this.TB_SubTotal.ReadOnly = true;
            this.TB_SubTotal.Size = new System.Drawing.Size(187, 22);
            this.TB_SubTotal.TabIndex = 7;
            // 
            // PN_Jawelleries
            // 
            this.PN_Jawelleries.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.PN_Jawelleries.Controls.Add(this.BT_Jawelleries3);
            this.PN_Jawelleries.Controls.Add(this.BT_Jawelleries2);
            this.PN_Jawelleries.Controls.Add(this.BT_Jawelleries1);
            this.PN_Jawelleries.Controls.Add(this.label33);
            this.PN_Jawelleries.Controls.Add(this.label34);
            this.PN_Jawelleries.Controls.Add(this.label35);
            this.PN_Jawelleries.Controls.Add(this.label36);
            this.PN_Jawelleries.Controls.Add(this.label37);
            this.PN_Jawelleries.Controls.Add(this.label38);
            this.PN_Jawelleries.Controls.Add(this.pictureBox13);
            this.PN_Jawelleries.Controls.Add(this.pictureBox16);
            this.PN_Jawelleries.Controls.Add(this.pictureBox17);
            this.PN_Jawelleries.Location = new System.Drawing.Point(3, 37);
            this.PN_Jawelleries.Name = "PN_Jawelleries";
            this.PN_Jawelleries.Size = new System.Drawing.Size(575, 350);
            this.PN_Jawelleries.TabIndex = 13;
            this.PN_Jawelleries.Visible = false;
            // 
            // BT_Jawelleries3
            // 
            this.BT_Jawelleries3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Jawelleries3.Location = new System.Drawing.Point(396, 311);
            this.BT_Jawelleries3.Name = "BT_Jawelleries3";
            this.BT_Jawelleries3.Size = new System.Drawing.Size(52, 25);
            this.BT_Jawelleries3.TabIndex = 11;
            this.BT_Jawelleries3.Text = "Keranjang";
            this.BT_Jawelleries3.UseVisualStyleBackColor = true;
            this.BT_Jawelleries3.Click += new System.EventHandler(this.BT_Jawelleries3_Click);
            // 
            // BT_Jawelleries2
            // 
            this.BT_Jawelleries2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Jawelleries2.Location = new System.Drawing.Point(205, 315);
            this.BT_Jawelleries2.Name = "BT_Jawelleries2";
            this.BT_Jawelleries2.Size = new System.Drawing.Size(52, 25);
            this.BT_Jawelleries2.TabIndex = 10;
            this.BT_Jawelleries2.Text = "Keranjang";
            this.BT_Jawelleries2.UseVisualStyleBackColor = true;
            this.BT_Jawelleries2.Click += new System.EventHandler(this.BT_Jawelleries2_Click);
            // 
            // BT_Jawelleries1
            // 
            this.BT_Jawelleries1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Jawelleries1.Location = new System.Drawing.Point(15, 315);
            this.BT_Jawelleries1.Name = "BT_Jawelleries1";
            this.BT_Jawelleries1.Size = new System.Drawing.Size(52, 25);
            this.BT_Jawelleries1.TabIndex = 9;
            this.BT_Jawelleries1.Text = "Keranjang";
            this.BT_Jawelleries1.UseVisualStyleBackColor = true;
            this.BT_Jawelleries1.Click += new System.EventHandler(this.BT_Jawelleries1_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(393, 292);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 16);
            this.label33.TabIndex = 8;
            this.label33.Text = "Rp. 500.000";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(202, 292);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 16);
            this.label34.TabIndex = 7;
            this.label34.Text = "Rp. 1.000.000";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(12, 292);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(85, 16);
            this.label35.TabIndex = 6;
            this.label35.Text = "Rp. 5.000.000";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(392, 255);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(78, 22);
            this.label36.TabIndex = 5;
            this.label36.Text = "Platinum";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(201, 255);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(46, 22);
            this.label37.TabIndex = 4;
            this.label37.Text = "Gold";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(11, 255);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(80, 22);
            this.label38.TabIndex = 3;
            this.label38.Text = "Diamond";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::TH_WEEK_6.Properties.Resources.Platinum;
            this.pictureBox13.Location = new System.Drawing.Point(396, 14);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(167, 229);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 2;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::TH_WEEK_6.Properties.Resources.Gold;
            this.pictureBox16.Location = new System.Drawing.Point(205, 14);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(167, 229);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 1;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::TH_WEEK_6.Properties.Resources.Diamond;
            this.pictureBox17.Location = new System.Drawing.Point(15, 13);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(167, 229);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 0;
            this.pictureBox17.TabStop = false;
            // 
            // PN_Others
            // 
            this.PN_Others.Controls.Add(this.BT_Other);
            this.PN_Others.Controls.Add(this.TB_Nama);
            this.PN_Others.Controls.Add(this.TB_Harga);
            this.PN_Others.Controls.Add(this.label41);
            this.PN_Others.Controls.Add(this.label40);
            this.PN_Others.Controls.Add(this.BT_Upload);
            this.PN_Others.Controls.Add(this.label39);
            this.PN_Others.Controls.Add(this.PB_New);
            this.PN_Others.Location = new System.Drawing.Point(6, 27);
            this.PN_Others.Name = "PN_Others";
            this.PN_Others.Size = new System.Drawing.Size(517, 350);
            this.PN_Others.TabIndex = 15;
            this.PN_Others.Visible = false;
            this.PN_Others.Paint += new System.Windows.Forms.PaintEventHandler(this.PN_Others_Paint);
            // 
            // BT_Other
            // 
            this.BT_Other.Location = new System.Drawing.Point(238, 211);
            this.BT_Other.Name = "BT_Other";
            this.BT_Other.Size = new System.Drawing.Size(99, 32);
            this.BT_Other.TabIndex = 7;
            this.BT_Other.Text = "Keranjang";
            this.BT_Other.UseVisualStyleBackColor = true;
            this.BT_Other.Click += new System.EventHandler(this.BT_Other_Click);
            // 
            // TB_Nama
            // 
            this.TB_Nama.Location = new System.Drawing.Point(238, 94);
            this.TB_Nama.Name = "TB_Nama";
            this.TB_Nama.Size = new System.Drawing.Size(185, 22);
            this.TB_Nama.TabIndex = 6;
            this.TB_Nama.TextChanged += new System.EventHandler(this.TB_Nama_TextChanged);
            // 
            // TB_Harga
            // 
            this.TB_Harga.Location = new System.Drawing.Point(238, 167);
            this.TB_Harga.Name = "TB_Harga";
            this.TB_Harga.Size = new System.Drawing.Size(185, 22);
            this.TB_Harga.TabIndex = 5;
            this.TB_Harga.TextChanged += new System.EventHandler(this.TB_Harga_TextChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(235, 75);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(72, 16);
            this.label41.TabIndex = 4;
            this.label41.Text = "Item Name";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(235, 148);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 16);
            this.label40.TabIndex = 3;
            this.label40.Text = "Item Price";
            // 
            // BT_Upload
            // 
            this.BT_Upload.Location = new System.Drawing.Point(348, 14);
            this.BT_Upload.Name = "BT_Upload";
            this.BT_Upload.Size = new System.Drawing.Size(75, 25);
            this.BT_Upload.TabIndex = 2;
            this.BT_Upload.Text = "Upload";
            this.BT_Upload.UseVisualStyleBackColor = true;
            this.BT_Upload.Click += new System.EventHandler(this.BT_Upload_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(235, 14);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(93, 16);
            this.label39.TabIndex = 1;
            this.label39.Text = "Upload Image";
            // 
            // PB_New
            // 
            this.PB_New.Location = new System.Drawing.Point(39, 55);
            this.PB_New.Name = "PB_New";
            this.PB_New.Size = new System.Drawing.Size(176, 246);
            this.PB_New.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_New.TabIndex = 0;
            this.PB_New.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH_WEEK_6.Properties.Resources.T_Shirt_Biru;
            this.pictureBox1.Location = new System.Drawing.Point(15, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 229);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TH_WEEK_6.Properties.Resources.T_Shirt_Coklat;
            this.pictureBox2.Location = new System.Drawing.Point(205, 14);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(167, 229);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TH_WEEK_6.Properties.Resources.T_Shirt_Light_Grey;
            this.pictureBox3.Location = new System.Drawing.Point(396, 14);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(167, 229);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 22);
            this.label3.TabIndex = 3;
            this.label3.Text = "Uniklo Biru";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(201, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 22);
            this.label4.TabIndex = 4;
            this.label4.Text = "Uniklo Coklat Saku";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(392, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 22);
            this.label5.TabIndex = 5;
            this.label5.Text = "Uniklo Khaki";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Rp. 200.000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(202, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Rp. 250.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(393, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Rp. 200.000";
            // 
            // BT_TShirt1
            // 
            this.BT_TShirt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_TShirt1.Location = new System.Drawing.Point(15, 315);
            this.BT_TShirt1.Name = "BT_TShirt1";
            this.BT_TShirt1.Size = new System.Drawing.Size(52, 25);
            this.BT_TShirt1.TabIndex = 9;
            this.BT_TShirt1.Text = "Keranjang";
            this.BT_TShirt1.UseVisualStyleBackColor = true;
            this.BT_TShirt1.Click += new System.EventHandler(this.BT_TShirt1_Click);
            // 
            // BT_TShirt2
            // 
            this.BT_TShirt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_TShirt2.Location = new System.Drawing.Point(205, 315);
            this.BT_TShirt2.Name = "BT_TShirt2";
            this.BT_TShirt2.Size = new System.Drawing.Size(52, 25);
            this.BT_TShirt2.TabIndex = 10;
            this.BT_TShirt2.Text = "Keranjang";
            this.BT_TShirt2.UseVisualStyleBackColor = true;
            this.BT_TShirt2.Click += new System.EventHandler(this.BT_TShirt2_Click);
            // 
            // BT_TShirt3
            // 
            this.BT_TShirt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_TShirt3.Location = new System.Drawing.Point(396, 311);
            this.BT_TShirt3.Name = "BT_TShirt3";
            this.BT_TShirt3.Size = new System.Drawing.Size(52, 25);
            this.BT_TShirt3.TabIndex = 11;
            this.BT_TShirt3.Text = "Keranjang";
            this.BT_TShirt3.UseVisualStyleBackColor = true;
            this.BT_TShirt3.Click += new System.EventHandler(this.BT_TShirt3_Click);
            // 
            // Panel_Shoes
            // 
            this.Panel_Shoes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel_Shoes.Controls.Add(this.pictureBox15);
            this.Panel_Shoes.Controls.Add(this.BT_Shoes3);
            this.Panel_Shoes.Controls.Add(this.BT_Shoes2);
            this.Panel_Shoes.Controls.Add(this.BT_Shoes1);
            this.Panel_Shoes.Controls.Add(this.label27);
            this.Panel_Shoes.Controls.Add(this.label28);
            this.Panel_Shoes.Controls.Add(this.label29);
            this.Panel_Shoes.Controls.Add(this.label30);
            this.Panel_Shoes.Controls.Add(this.label31);
            this.Panel_Shoes.Controls.Add(this.label32);
            this.Panel_Shoes.Controls.Add(this.PN_Shoes);
            this.Panel_Shoes.Controls.Add(this.pictureBox14);
            this.Panel_Shoes.Location = new System.Drawing.Point(11, 33);
            this.Panel_Shoes.Name = "Panel_Shoes";
            this.Panel_Shoes.Size = new System.Drawing.Size(575, 356);
            this.Panel_Shoes.TabIndex = 12;
            this.Panel_Shoes.Visible = false;
            this.Panel_Shoes.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Shoes_Paint);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::TH_WEEK_6.Properties.Resources.Sepatu_Nike;
            this.pictureBox15.Location = new System.Drawing.Point(15, 13);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(167, 229);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            // 
            // BT_Shoes3
            // 
            this.BT_Shoes3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shoes3.Location = new System.Drawing.Point(396, 311);
            this.BT_Shoes3.Name = "BT_Shoes3";
            this.BT_Shoes3.Size = new System.Drawing.Size(52, 25);
            this.BT_Shoes3.TabIndex = 11;
            this.BT_Shoes3.Text = "Keranjang";
            this.BT_Shoes3.UseVisualStyleBackColor = true;
            this.BT_Shoes3.Click += new System.EventHandler(this.BT_Shoes3_Click);
            // 
            // BT_Shoes2
            // 
            this.BT_Shoes2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shoes2.Location = new System.Drawing.Point(205, 315);
            this.BT_Shoes2.Name = "BT_Shoes2";
            this.BT_Shoes2.Size = new System.Drawing.Size(52, 25);
            this.BT_Shoes2.TabIndex = 10;
            this.BT_Shoes2.Text = "Keranjang";
            this.BT_Shoes2.UseVisualStyleBackColor = true;
            this.BT_Shoes2.Click += new System.EventHandler(this.BT_Shoes2_Click);
            // 
            // BT_Shoes1
            // 
            this.BT_Shoes1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shoes1.Location = new System.Drawing.Point(15, 315);
            this.BT_Shoes1.Name = "BT_Shoes1";
            this.BT_Shoes1.Size = new System.Drawing.Size(52, 25);
            this.BT_Shoes1.TabIndex = 9;
            this.BT_Shoes1.Text = "Keranjang";
            this.BT_Shoes1.UseVisualStyleBackColor = true;
            this.BT_Shoes1.Click += new System.EventHandler(this.BT_Shoes1_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(393, 292);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 16);
            this.label27.TabIndex = 8;
            this.label27.Text = "Rp. 1.200.000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(202, 292);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 16);
            this.label28.TabIndex = 7;
            this.label28.Text = "Rp. 1.250.000";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(12, 292);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(85, 16);
            this.label29.TabIndex = 6;
            this.label29.Text = "Rp. 1.100.000";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(392, 255);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 22);
            this.label30.TabIndex = 5;
            this.label30.Text = "Sepatu Adidas";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(201, 255);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(126, 22);
            this.label31.TabIndex = 4;
            this.label31.Text = "Repatu Rebook";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(11, 255);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(102, 22);
            this.label32.TabIndex = 3;
            this.label32.Text = "Sepatu Nike";
            // 
            // PN_Shoes
            // 
            this.PN_Shoes.Image = global::TH_WEEK_6.Properties.Resources.Sepatu_Adidas;
            this.PN_Shoes.Location = new System.Drawing.Point(396, 14);
            this.PN_Shoes.Name = "PN_Shoes";
            this.PN_Shoes.Size = new System.Drawing.Size(167, 229);
            this.PN_Shoes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PN_Shoes.TabIndex = 2;
            this.PN_Shoes.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::TH_WEEK_6.Properties.Resources.Sepatu_Rebook;
            this.pictureBox14.Location = new System.Drawing.Point(205, 14);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(167, 229);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 1;
            this.pictureBox14.TabStop = false;
            // 
            // PN_TShirt
            // 
            this.PN_TShirt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PN_TShirt.Controls.Add(this.BT_TShirt3);
            this.PN_TShirt.Controls.Add(this.BT_TShirt2);
            this.PN_TShirt.Controls.Add(this.BT_TShirt1);
            this.PN_TShirt.Controls.Add(this.label8);
            this.PN_TShirt.Controls.Add(this.label7);
            this.PN_TShirt.Controls.Add(this.label6);
            this.PN_TShirt.Controls.Add(this.label5);
            this.PN_TShirt.Controls.Add(this.label4);
            this.PN_TShirt.Controls.Add(this.label3);
            this.PN_TShirt.Controls.Add(this.pictureBox3);
            this.PN_TShirt.Controls.Add(this.pictureBox2);
            this.PN_TShirt.Controls.Add(this.pictureBox1);
            this.PN_TShirt.Location = new System.Drawing.Point(12, 31);
            this.PN_TShirt.Name = "PN_TShirt";
            this.PN_TShirt.Size = new System.Drawing.Size(612, 359);
            this.PN_TShirt.TabIndex = 5;
            this.PN_TShirt.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::TH_WEEK_6.Properties.Resources.Celana_Hijau;
            this.pictureBox12.Location = new System.Drawing.Point(15, 13);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(167, 229);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::TH_WEEK_6.Properties.Resources.Celana_Coklat;
            this.pictureBox11.Location = new System.Drawing.Point(205, 14);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(167, 229);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 1;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::TH_WEEK_6.Properties.Resources.Celana_Biru_Dongker;
            this.pictureBox10.Location = new System.Drawing.Point(396, 14);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(167, 229);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(11, 255);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(106, 22);
            this.label26.TabIndex = 3;
            this.label26.Text = "Celana Hijau";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(201, 255);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(115, 22);
            this.label25.TabIndex = 4;
            this.label25.Text = "Celana Coklat";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(392, 255);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(84, 19);
            this.label24.TabIndex = 5;
            this.label24.Text = "Celana Biru";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(12, 292);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 16);
            this.label23.TabIndex = 6;
            this.label23.Text = "Rp. 300.000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(202, 292);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 16);
            this.label22.TabIndex = 7;
            this.label22.Text = "Rp. 250.000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(393, 292);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 16);
            this.label21.TabIndex = 8;
            this.label21.Text = "Rp. 175.000";
            // 
            // BT_LongPants1
            // 
            this.BT_LongPants1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_LongPants1.Location = new System.Drawing.Point(15, 315);
            this.BT_LongPants1.Name = "BT_LongPants1";
            this.BT_LongPants1.Size = new System.Drawing.Size(52, 25);
            this.BT_LongPants1.TabIndex = 9;
            this.BT_LongPants1.Text = "Keranjang";
            this.BT_LongPants1.UseVisualStyleBackColor = true;
            this.BT_LongPants1.Click += new System.EventHandler(this.BT_LongPants1_Click);
            // 
            // BT_LongPants2
            // 
            this.BT_LongPants2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_LongPants2.Location = new System.Drawing.Point(205, 315);
            this.BT_LongPants2.Name = "BT_LongPants2";
            this.BT_LongPants2.Size = new System.Drawing.Size(52, 25);
            this.BT_LongPants2.TabIndex = 10;
            this.BT_LongPants2.Text = " Keranjang";
            this.BT_LongPants2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BT_LongPants2.UseVisualStyleBackColor = true;
            this.BT_LongPants2.Click += new System.EventHandler(this.BT_LongPants2_Click);
            // 
            // BT_LongPants3
            // 
            this.BT_LongPants3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_LongPants3.Location = new System.Drawing.Point(396, 315);
            this.BT_LongPants3.Name = "BT_LongPants3";
            this.BT_LongPants3.Size = new System.Drawing.Size(52, 25);
            this.BT_LongPants3.TabIndex = 11;
            this.BT_LongPants3.Text = "Keranjang";
            this.BT_LongPants3.UseVisualStyleBackColor = true;
            this.BT_LongPants3.Click += new System.EventHandler(this.BT_LongPants3_Click);
            // 
            // PN_LongPants
            // 
            this.PN_LongPants.Controls.Add(this.BT_LongPants3);
            this.PN_LongPants.Controls.Add(this.BT_LongPants2);
            this.PN_LongPants.Controls.Add(this.BT_LongPants1);
            this.PN_LongPants.Controls.Add(this.label21);
            this.PN_LongPants.Controls.Add(this.label22);
            this.PN_LongPants.Controls.Add(this.label23);
            this.PN_LongPants.Controls.Add(this.label24);
            this.PN_LongPants.Controls.Add(this.label25);
            this.PN_LongPants.Controls.Add(this.label26);
            this.PN_LongPants.Controls.Add(this.pictureBox10);
            this.PN_LongPants.Controls.Add(this.pictureBox11);
            this.PN_LongPants.Controls.Add(this.pictureBox12);
            this.PN_LongPants.Location = new System.Drawing.Point(29, 30);
            this.PN_LongPants.Name = "PN_LongPants";
            this.PN_LongPants.Size = new System.Drawing.Size(575, 388);
            this.PN_LongPants.TabIndex = 14;
            this.PN_LongPants.Visible = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::TH_WEEK_6.Properties.Resources.Celana_Pendek_Hijau;
            this.pictureBox9.Location = new System.Drawing.Point(15, 13);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(167, 229);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::TH_WEEK_6.Properties.Resources.Celana_Pendek_Hitam;
            this.pictureBox8.Location = new System.Drawing.Point(205, 14);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(167, 229);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::TH_WEEK_6.Properties.Resources.Celana_Pendek_Abu_Abu;
            this.pictureBox7.Location = new System.Drawing.Point(396, 14);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(167, 229);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(11, 255);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(167, 22);
            this.label20.TabIndex = 3;
            this.label20.Text = "Celana Pendek Hijau";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(201, 255);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(174, 22);
            this.label19.TabIndex = 4;
            this.label19.Text = "Celana Pendek Hitam";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(392, 255);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(168, 19);
            this.label18.TabIndex = 5;
            this.label18.Text = "Celana Pendek Abu Abu";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 292);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 16);
            this.label17.TabIndex = 6;
            this.label17.Text = "Rp. 100.000";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(202, 292);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 16);
            this.label16.TabIndex = 7;
            this.label16.Text = "Rp. 50.000";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(393, 292);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 16);
            this.label15.TabIndex = 8;
            this.label15.Text = "Rp. 75.000";
            // 
            // BT_Pants1
            // 
            this.BT_Pants1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Pants1.Location = new System.Drawing.Point(15, 315);
            this.BT_Pants1.Name = "BT_Pants1";
            this.BT_Pants1.Size = new System.Drawing.Size(52, 25);
            this.BT_Pants1.TabIndex = 9;
            this.BT_Pants1.Text = "Keranjang";
            this.BT_Pants1.UseVisualStyleBackColor = true;
            this.BT_Pants1.Click += new System.EventHandler(this.BT_Pants1_Click);
            // 
            // BT_Pants2
            // 
            this.BT_Pants2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Pants2.Location = new System.Drawing.Point(205, 315);
            this.BT_Pants2.Name = "BT_Pants2";
            this.BT_Pants2.Size = new System.Drawing.Size(52, 25);
            this.BT_Pants2.TabIndex = 10;
            this.BT_Pants2.Text = "Keranjang";
            this.BT_Pants2.UseVisualStyleBackColor = true;
            this.BT_Pants2.Click += new System.EventHandler(this.BT_Pants2_Click);
            // 
            // BT_Pants3
            // 
            this.BT_Pants3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Pants3.Location = new System.Drawing.Point(396, 315);
            this.BT_Pants3.Name = "BT_Pants3";
            this.BT_Pants3.Size = new System.Drawing.Size(52, 25);
            this.BT_Pants3.TabIndex = 11;
            this.BT_Pants3.Text = "Keranjang";
            this.BT_Pants3.UseVisualStyleBackColor = true;
            this.BT_Pants3.Click += new System.EventHandler(this.BT_Pants3_Click);
            // 
            // PN_Pants
            // 
            this.PN_Pants.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.PN_Pants.Controls.Add(this.BT_Pants3);
            this.PN_Pants.Controls.Add(this.BT_Pants2);
            this.PN_Pants.Controls.Add(this.BT_Pants1);
            this.PN_Pants.Controls.Add(this.label15);
            this.PN_Pants.Controls.Add(this.label16);
            this.PN_Pants.Controls.Add(this.label17);
            this.PN_Pants.Controls.Add(this.label18);
            this.PN_Pants.Controls.Add(this.label19);
            this.PN_Pants.Controls.Add(this.label20);
            this.PN_Pants.Controls.Add(this.pictureBox7);
            this.PN_Pants.Controls.Add(this.pictureBox8);
            this.PN_Pants.Controls.Add(this.pictureBox9);
            this.PN_Pants.Location = new System.Drawing.Point(3, 40);
            this.PN_Pants.Name = "PN_Pants";
            this.PN_Pants.Size = new System.Drawing.Size(574, 363);
            this.PN_Pants.TabIndex = 13;
            this.PN_Pants.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::TH_WEEK_6.Properties.Resources.Kemeja_Hijau;
            this.pictureBox6.Location = new System.Drawing.Point(15, 13);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(167, 229);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(205, 14);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(167, 229);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TH_WEEK_6.Properties.Resources.Kemeja_Kotak_Kotak;
            this.pictureBox4.Location = new System.Drawing.Point(396, 14);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(167, 229);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(11, 255);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 22);
            this.label14.TabIndex = 3;
            this.label14.Text = "Kemeja Hijau";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(201, 255);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 22);
            this.label13.TabIndex = 4;
            this.label13.Text = "Kemeja Putih";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(392, 255);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(162, 22);
            this.label12.TabIndex = 5;
            this.label12.Text = "Kemeja Kotak Kotak";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 292);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 16);
            this.label11.TabIndex = 6;
            this.label11.Text = "Rp. 250.000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(202, 292);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 16);
            this.label10.TabIndex = 7;
            this.label10.Text = "Rp. 300.000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(393, 292);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Rp. 400.000";
            // 
            // BT_Shirt1
            // 
            this.BT_Shirt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shirt1.Location = new System.Drawing.Point(15, 315);
            this.BT_Shirt1.Name = "BT_Shirt1";
            this.BT_Shirt1.Size = new System.Drawing.Size(52, 25);
            this.BT_Shirt1.TabIndex = 9;
            this.BT_Shirt1.Text = "Keranjang";
            this.BT_Shirt1.UseVisualStyleBackColor = true;
            this.BT_Shirt1.Click += new System.EventHandler(this.BT_Shirt1_Click);
            // 
            // BT_Shirt2
            // 
            this.BT_Shirt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shirt2.Location = new System.Drawing.Point(205, 315);
            this.BT_Shirt2.Name = "BT_Shirt2";
            this.BT_Shirt2.Size = new System.Drawing.Size(52, 25);
            this.BT_Shirt2.TabIndex = 10;
            this.BT_Shirt2.Text = "Keranjang";
            this.BT_Shirt2.UseVisualStyleBackColor = true;
            this.BT_Shirt2.Click += new System.EventHandler(this.BT_Shirt2_Click);
            // 
            // BT_Shirt3
            // 
            this.BT_Shirt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 4.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Shirt3.Location = new System.Drawing.Point(396, 315);
            this.BT_Shirt3.Name = "BT_Shirt3";
            this.BT_Shirt3.Size = new System.Drawing.Size(52, 25);
            this.BT_Shirt3.TabIndex = 11;
            this.BT_Shirt3.Text = "Keranjang";
            this.BT_Shirt3.UseVisualStyleBackColor = true;
            this.BT_Shirt3.Click += new System.EventHandler(this.BT_Shirt3_Click);
            // 
            // PN_Shirt
            // 
            this.PN_Shirt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PN_Shirt.Controls.Add(this.BT_Shirt3);
            this.PN_Shirt.Controls.Add(this.BT_Shirt2);
            this.PN_Shirt.Controls.Add(this.BT_Shirt1);
            this.PN_Shirt.Controls.Add(this.label9);
            this.PN_Shirt.Controls.Add(this.label10);
            this.PN_Shirt.Controls.Add(this.label11);
            this.PN_Shirt.Controls.Add(this.label12);
            this.PN_Shirt.Controls.Add(this.label13);
            this.PN_Shirt.Controls.Add(this.label14);
            this.PN_Shirt.Controls.Add(this.pictureBox4);
            this.PN_Shirt.Controls.Add(this.pictureBox5);
            this.PN_Shirt.Controls.Add(this.pictureBox6);
            this.PN_Shirt.Location = new System.Drawing.Point(14, 33);
            this.PN_Shirt.Name = "PN_Shirt";
            this.PN_Shirt.Size = new System.Drawing.Size(575, 388);
            this.PN_Shirt.TabIndex = 12;
            this.PN_Shirt.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 526);
            this.Controls.Add(this.Panel_Shoes);
            this.Controls.Add(this.PN_Jawelleries);
            this.Controls.Add(this.PN_TShirt);
            this.Controls.Add(this.PN_LongPants);
            this.Controls.Add(this.PN_Pants);
            this.Controls.Add(this.PN_Others);
            this.Controls.Add(this.TB_SubTotal);
            this.Controls.Add(this.TB_Total);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGV_Keranjang);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.PN_Shirt);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "TOKPED";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Keranjang)).EndInit();
            this.PN_Jawelleries.ResumeLayout(false);
            this.PN_Jawelleries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.PN_Others.ResumeLayout(false);
            this.PN_Others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_New)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Panel_Shoes.ResumeLayout(false);
            this.Panel_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PN_Shoes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.PN_TShirt.ResumeLayout(false);
            this.PN_TShirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.PN_LongPants.ResumeLayout(false);
            this.PN_LongPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.PN_Pants.ResumeLayout(false);
            this.PN_Pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.PN_Shirt.ResumeLayout(false);
            this.PN_Shirt.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TShirt;
        private System.Windows.Forms.ToolStripMenuItem Shirt;
        private System.Windows.Forms.ToolStripMenuItem buttonWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Pants;
        private System.Windows.Forms.ToolStripMenuItem LongPants;
        private System.Windows.Forms.ToolStripMenuItem accesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Shoes;
        private System.Windows.Forms.ToolStripMenuItem Jawelleries;
        private System.Windows.Forms.ToolStripMenuItem Others;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView DGV_Keranjang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_Total;
        private System.Windows.Forms.TextBox TB_SubTotal;
        private System.Windows.Forms.Panel PN_Jawelleries;
        private System.Windows.Forms.Button BT_Jawelleries3;
        private System.Windows.Forms.Button BT_Jawelleries2;
        private System.Windows.Forms.Button BT_Jawelleries1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Panel PN_Others;
        private System.Windows.Forms.Button BT_Other;
        private System.Windows.Forms.TextBox TB_Nama;
        private System.Windows.Forms.TextBox TB_Harga;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button BT_Upload;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.PictureBox PB_New;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button BT_TShirt1;
        private System.Windows.Forms.Button BT_TShirt2;
        private System.Windows.Forms.Button BT_TShirt3;
        private System.Windows.Forms.Panel Panel_Shoes;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Button BT_Shoes3;
        private System.Windows.Forms.Button BT_Shoes2;
        private System.Windows.Forms.Button BT_Shoes1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox PN_Shoes;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Panel PN_TShirt;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button BT_LongPants1;
        private System.Windows.Forms.Button BT_LongPants2;
        private System.Windows.Forms.Button BT_LongPants3;
        private System.Windows.Forms.Panel PN_LongPants;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button BT_Pants1;
        private System.Windows.Forms.Button BT_Pants2;
        private System.Windows.Forms.Button BT_Pants3;
        private System.Windows.Forms.Panel PN_Pants;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button BT_Shirt1;
        private System.Windows.Forms.Button BT_Shirt2;
        private System.Windows.Forms.Button BT_Shirt3;
        private System.Windows.Forms.Panel PN_Shirt;
    }
}

